package com.example.myappktx.di

import dagger.Component
import dagger.Module
import dagger.Provides

@Module
class AppModule {
    @Provides
    fun inject(): String{return "alll poluchilos"
    }
}