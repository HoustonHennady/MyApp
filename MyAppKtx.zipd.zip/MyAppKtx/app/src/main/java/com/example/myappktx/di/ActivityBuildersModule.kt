package com.example.myappktx.di

import com.example.myappktx.MainActivity
import com.example.myappktx.categoryFragment
import dagger.Module
import dagger.Provides
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBuildersModule {

    @ContributesAndroidInjector
    abstract fun injectMainActivity(): MainActivity
    @ContributesAndroidInjector
    abstract fun injectcategoryFargment(): categoryFragment





}